package net.rafaeltoledo.restaurante;

import android.app.Activity;
import android.os.Bundle;

public class AlarmeActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.alarme);
	}
}
