/** Automatically generated file. DO NOT MODIFY */
package net.rafaeltoledo.restaurante;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}