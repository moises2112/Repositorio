/** Automatically generated file. DO NOT MODIFY */
package com.javacodegeeks.android.androidscrollablecontent;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}